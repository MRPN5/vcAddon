const express = require('express');
const { WebSocketServer } = require('ws');
const path = require('path');
const { settings } = require('cluster');
const { time } = require('console');

const app = express();
const PORT = process.env.PORT || 8080;

let vcMembers = new Set();
let minecraftPlayers = [];

let now_time = performance.now();
let wait_time = 500;
// 1. Webサイト（HTML）を公開する設定
// 後で作る 'public' フォルダの中身をブラウザで見れるようにします
app.use(express.static(path.join(__dirname, 'public')));

// 2. サーバーを起動
const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`🌍 Webサイトはこちら: http://localhost:${PORT}`);
});

// 3. 同じポートでWebSocket（リアルタイム通信）の受付を開始
const wss = new WebSocketServer({ server });

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

/*app.post('/pos', (req, res) => {
    if (req !== undefined) {
        if (req.body !== undefined) {
            if (req.body.data !== undefined) {
                if (req.body.data.host == "minecraft") {
                    if (req.body.data.content.title == "playerData") {
                        const playersData = req.body.data.content.data;

                        // ▼ 受け取ったデータを、繋がっているブラウザ全員に WebSocket で転送する
                        wss.clients.forEach(client => {
                            if (client.readyState === 1) { // 1 = WebSocket接続中
                                client.send(JSON.stringify({
                                    type: "positions",
                                    data: playersData
                                }));
                            }
                        });
                    }
                }
            }
        }
    }
    res.sendStatus(200); // マイクラに「受け取ったよ」と返す
});*/

wss.on('connection', (ws) => {
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
    console.log('✅ 誰かが接続しました（マイクラ または ブラウザ）');
    //console.log(`${}`);
    const subscribeMsg = {
        "header": {
            "requestId": "00000000-0000-0000-0000-000000000000",
            "messagePurpose": "subscribe",
            "version": 1,
            "messageType": "commandRequest"
        },
        "body": {
            "eventName": "PlayerMessage" // scriptEventはここに含まれます
        }
    };
    ws.send(JSON.stringify(subscribeMsg));
    // データを受け取ったときの処理
    ws.on('message', (data) => {
        //console.log("recieved");
        try {
            // 2. 文字列をJSONとして解析する（ここで初めて中身をいじれるようになる）
            const rawString = data.toString();
            const json = JSON.parse(rawString);
            //console.log(json);
            if (json.type === 'join-vc') {
                ws.playerName = json.name; // この接続に名前を紐付ける
                vcMembers.add(json.name);
                broadcastVCList();
            }
            if (json.host == "browser") {
                if (json.content !== undefined) {
                    if (json.content.title == "connected") {
                        ws.isBrowser = true;
                        console.log("browser connected");
                    }
                }
            } else {
                //console.log("recieve minecraft message");
                if (json.body !== undefined) {
                    const body = json.body;
                    const temp_message = body.message
                    if (temp_message.includes("#POS")) {
                        const message = temp_message.split("#POS")[1];
                        const data = message.split(" ").map(value => {
                            const datas = value.split(",");
                            if (datas[0] == "setting") {
                                return { name: datas[0], template: datas[1], dict: datas[2], spectator: datas[3] };
                            } else {
                                return { name: datas[0], x: datas[1], y: datas[2], z: datas[3], mode: datas[4], dim: datas[5], time: datas[6] };
                            }
                        });
                        console.log("recieve minecraft");
                        if (performance.now() - now_time > wait_time) {
                            console.log("broadcast!");
                            broadcast(JSON.stringify({
                                type: "positions",
                                settings: data[0], // 最初の要素は設定用
                                data: data.slice(1)
                            }));
                            now_time=performance.now();
                        }
                    }
                }

            }
        } catch (e) {
            console.log(e);// JSONじゃない変なデータが来ても壊れないように守る
        }
    });

    ws.on('close', () => {
        console.log('❌ 接続が切れました');
        if (ws.playerName) {
            vcMembers.delete(ws.playerName);
            broadcastVCList();
        }
    });
});

function broadcastVCList() {
    const msg = JSON.stringify({
        type: 'vc-list',
        members: Array.from(vcMembers)
    });
    broadcast(msg);
}

function broadcast(msg) {
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(msg);
        }
    });
}

function updateData(data) {
    // 1. 配列の中に同じ名前のプレイヤーがいるか探す
    const index = minecraftPlayers.findIndex(p => p.name === data.name);

    if (index !== -1) {
        // 2. すでに見つかった場合はデータを上書き（更新）
        minecraftPlayers[index] = data;
    } else {
        // 3. 見つからなかった場合は新しく配列に追加
        minecraftPlayers.push(data);
    }
}