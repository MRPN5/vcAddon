const express = require('express');
const { WebSocketServer } = require('ws');
const path = require('path');
const { settings } = require('cluster');
const { time } = require('console');

const app = express();
const PORT = process.env.PORT || 8080;
let IS_DEBUG = (process.env.DEBUG === 'true');
console.log(`debug is ${IS_DEBUG}`);
let vcMembers = new Set();
let minecraftPlayers = [];

let now_time = performance.now();
let wait_time = 500;
// 1. Webサイト（HTML）を公開する設定
// 後で作る 'public' フォルダの中身をブラウザで見れるようにします
app.use(express.static(path.join(__dirname, 'public')));

// 2. サーバーを起動
const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`🌍 Webサイトはこちら: http://localhost:${PORT}`);
});

// 3. 同じポートでWebSocket（リアルタイム通信）の受付を開始
const wss = new WebSocketServer({ server });

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

/*app.post('/pos', (req, res) => {
    if (req !== undefined) {
        if (req.body !== undefined) {
            if (req.body.data !== undefined) {
                if (req.body.data.host == "minecraft") {
                    if (req.body.data.content.title == "playerData") {
                        const playersData = req.body.data.content.data;

                        // ▼ 受け取ったデータを、繋がっているブラウザ全員に WebSocket で転送する
                        wss.clients.forEach(client => {
                            if (client.readyState === 1) { // 1 = WebSocket接続中
                                client.send(JSON.stringify({
                                    type: "positions",
                                    data: playersData
                                }));
                            }
                        });
                    }
                }
            }
        }
    }
    res.sendStatus(200); // マイクラに「受け取ったよ」と返す
});*/

wss.on('connection', (ws) => {
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
    console.log('✅ 誰かが接続しました（マイクラ または ブラウザ）');
    //console.log(`${}`);
    const subscribeMsg = {
        "header": {
            "requestId": "00000000-0000-0000-0000-000000000000",
            "messagePurpose": "subscribe",
            "version": 1,
            "messageType": "commandRequest"
        },
        "body": {
            "eventName": "PlayerMessage" // scriptEventはここに含まれます
        }
    };
    const tagMsg = {
        header: {
            requestId: "set-connection-tag",
            messagePurpose: "commandRequest",
            version: 1,
            messageType: "commandRequest"
        },
        body: {
            commandLine: "tag @s add host", // タグを付与
            version: 1
        }
    };
    ws.send(JSON.stringify(subscribeMsg));
    ws.send(JSON.stringify(tagMsg));

    // データを受け取ったときの処理
    ws.on('message', (data) => {
        //console.log("recieved");
        try {
            // 2. 文字列をJSONとして解析する（ここで初めて中身をいじれるようになる）
            const rawString = data.toString();
            const json = JSON.parse(rawString);
            //console.log(json);
            if (json.type === 'join-vc') {
                ws.playerName = json.name; // この接続に名前を紐付ける
                vcMembers.add(json.name);
                broadcastVCList();
            }
            if (json.type === 'leave-vc') {
                vcMembers.delete(json.name);
                broadcastVCList();
            }
            if (json.host == "browser") {
                if (json.content !== undefined) {
                    if (json.content.title == "connected") {
                        ws.isBrowser = true;
                        if (IS_DEBUG)console.log("browser connected");
                        broadcastVCList();
                    }
                }
            } else {
                //console.log("recieve minecraft message");
                if (json.body !== undefined) {
                    const body = json.body;
                    const temp_message = body.message
                    if (body.message !== undefined) {
                        if (temp_message.includes("#POS")) {
                            const message = temp_message.split("#POS")[1];
                            const data = message.split(" ").map(value => {
                                const datas = value.split(",");
                                if (datas[0] == "setting") {
                                    return { name: datas[0], template: datas[1], dict: datas[2], spectator: datas[3] };
                                } else {
                                    return { name: datas[0], x: datas[1], y: datas[2], z: datas[3], mode: datas[4], dim: datas[5], time: datas[6] };
                                }
                            });
                            if (IS_DEBUG)console.log("recieve minecraft");
                            if (performance.now() - now_time > wait_time) {
                                if (IS_DEBUG)console.log("broadcast!");
                                broadcast(JSON.stringify({
                                    type: "positions",
                                    settings: data[0], // 最初の要素は設定用
                                    data: data.slice(1)
                                }));
                                now_time = performance.now();

                                ws.send(JSON.stringify(tagMsg));
                            }
                        }
                    }
                }

            }
        } catch (e) {
            console.log(e);// JSONじゃない変なデータが来ても壊れないように守る
        }
    });

    ws.on('close', () => {
        console.log('❌ 接続が切れました');
        if (ws.playerName) {
            vcMembers.delete(ws.playerName);
            broadcastVCList();
        }
    });
});

function broadcastVCList() {
    const msg = JSON.stringify({
        type: 'vc-list',
        members: Array.from(vcMembers)
    });
    broadcast(msg);
}

function broadcast(msg) {
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(msg);
        }
    });
}

function updateData(data) {
    // 1. 配列の中に同じ名前のプレイヤーがいるか探す
    const index = minecraftPlayers.findIndex(p => p.name === data.name);

    if (index !== -1) {
        // 2. すでに見つかった場合はデータを上書き（更新）
        minecraftPlayers[index] = data;
    } else {
        // 3. 見つからなかった場合は新しく配列に追加
        minecraftPlayers.push(data);
    }
}

process.stdin.setEncoding('utf8');
process.stdin.on('data', (input) => {
    const command = input.trim(); // 改行などを取り除く

    if (command === 'clients') {
        console.log("\n--- 現在のクライアント一覧 ---");
        const clientList = [];

        wss.clients.forEach(client => {
            clientList.push({
                name: client.playerName || "不明 (接続中...)",
                type: client.isBrowser ? "🌐 Browser" : "⛏️ Minecraft",
                state: client.readyState === 1 ? "OPEN" : "CLOSED",
                ip: client._socket.remoteAddress.replace("::ffff:", "")
            });
        });

        if (clientList.length > 0) {
            console.table(clientList); // 表形式で綺麗に出す！
        } else {
            console.log("接続中のクライアントはいません。");
        }
        console.log("------------------------------\n");
    }

    // ついでにデバッグの切り替えもできるようにすると便利
    if (command === 'debug on') {
        // グローバルの IS_DEBUG を書き換える処理など
        IS_DEBUG = true;
        console.log("🛠 デバッグ表示をONにしました");
    }
    if (command === 'debug off') {
        // グローバルの IS_DEBUG を書き換える処理など
        IS_DEBUG = false;
        console.log("🛠 デバッグ表示をONにしました");
    }
});