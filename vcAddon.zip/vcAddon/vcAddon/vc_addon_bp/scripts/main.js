import {
    system,
    world,
    CommandPermissionLevel,
    CustomCommandParamType,
    Player
} from "@minecraft/server";
import * as ui from '@minecraft/server-ui';

system.beforeEvents.startup.subscribe(ev => {
    ev.customCommandRegistry.registerCommand({
        name: "vc:start", // 【重要】必ず「ネームスペース:コマンド名」にする
        description: "VCに接続します。",
        permissionLevel: CommandPermissionLevel.Any, // 誰でも実行可能（Admin, Host等も指定可）
        cheatsRequired: false, // チートオフでも実行可能にするか

        // 必須パラメーター
        mandatoryParameters: [
        ]
        // 任意パラメーター（省略可能）を使いたい場合は optionalParameters: [] を追加します
    },
        // ③ コマンド実行時の処理
        (origin, templateName) => {
            system.run(async () => {
            });
        });
    ev.customCommandRegistry.registerCommand({
        name: "vc:template", // 【重要】必ず「ネームスペース:コマンド名」にする
        description: "VCの設定を行います。templateを操作します。none,jinroが利用可能です。",
        permissionLevel: CommandPermissionLevel.Any, // 誰でも実行可能（Admin, Host等も指定可）
        cheatsRequired: false, // チートオフでも実行可能にするか

        // 必須パラメーター
        mandatoryParameters: [
            {
                name: "templateName",
                type: CustomCommandParamType.String // 文字列を受け取る
            }
        ]
        // 任意パラメーター（省略可能）を使いたい場合は optionalParameters: [] を追加します
    },
        // ③ コマンド実行時の処理
        (origin, templateName) => {
            system.run(() => {
                world.setDynamicProperty("template", templateName);
            });
        });
    ev.customCommandRegistry.registerCommand({
        name: "vc:dict", // 【重要】必ず「ネームスペース:コマンド名」にする
        description: "話す距離を設定します。",
        permissionLevel: CommandPermissionLevel.Any, // 誰でも実行可能（Admin, Host等も指定可）
        cheatsRequired: false, // チートオフでも実行可能にするか

        // 必須パラメーター
        mandatoryParameters: [
            {
                name: "dictDistance",
                type: CustomCommandParamType.Float // 浮動小数点数を受け取る
            }
        ]
        // 任意パラメーター（省略可能）を使いたい場合は optionalParameters: [] を追加します
    },
        // ③ コマンド実行時の処理
        (origin, dictDistance) => {
            system.run(() => {
                world.setDynamicProperty("dictDistance", dictDistance);
            });
        });
    ev.customCommandRegistry.registerCommand({
        name: "vc:spectator", // 【重要】必ず「ネームスペース:コマンド名」にする
        description: "観戦者の表示設定を行います。none,all,nearが利用可能です。",
        permissionLevel: CommandPermissionLevel.Any, // 誰でも実行可能（Admin, Host等も指定可）
        cheatsRequired: false, // チートオフでも実行可能にするか

        // 必須パラメーター
        mandatoryParameters: [
            {
                name: "spectatorSetting",
                type: CustomCommandParamType.String // 文字列を受け取る
            }
        ]
        // 任意パラメーター（省略可能）を使いたい場合は optionalParameters: [] を追加します
    },
        // ③ コマンド実行時の処理
        (origin, spectatorSetting) => {
            system.run(() => {
                world.setDynamicProperty("spectatorSetting", spectatorSetting);
            });
        });
    ev.customCommandRegistry.registerCommand({
        name: "vc:setting", // 【重要】必ず「ネームスペース:コマンド名」にする
        description: "VCの設定を行います",
        permissionLevel: CommandPermissionLevel.Any, // 誰でも実行可能（Admin, Host等も指定可）
        cheatsRequired: false, // チートオフでも実行可能にするか

        // 必須パラメーター
        mandatoryParameters: [
        ]
        // 任意パラメーター（省略可能）を使いたい場合は optionalParameters: [] を追加します
    },
        // ③ コマンド実行時の処理
        (origin) => {
            // origin: コマンドの実行者などの情報（origin.sourceEntity など）
            // playerName: 入力されたパラメーター

            // 【重要】状態を変更する処理は system.run() で囲む
            system.run(() => {
            });
        });
});

system.runInterval(() => {
    let allPlayers = world.getAllPlayers();
    let datas = [];
    let setting = { template_setting: "none", dict: 30, spectator: "near" };//template_setting:jinro,none,  spectator:none,all,near
    if (world.getDynamicProperty("template") !== undefined) {
        setting.template_setting = world.getDynamicProperty("template");
    } else {
        world.setDynamicProperty("template", setting.template_setting);
    }
    if (world.getDynamicProperty("dictDistance") !== undefined) {
        setting.dict = world.getDynamicProperty("dictDistance");
    } else {
        world.setDynamicProperty("dictDistance", setting.dict);
    }
    if (world.getDynamicProperty("spectatorSetting") !== undefined) {
        setting.spectator = world.getDynamicProperty("spectatorSetting");
    } else {
        world.setDynamicProperty("spectatorSetting", setting.spectator);
    }

    allPlayers.forEach((value, index) => {
        datas.push({ name: value.name, x: value.location.x, y: value.location.y, mode: value.getGameMode(), z: value.location.z, dim: value.dimension.id, time: world.getTimeOfDay() });
    });
    let sendData = datas.map(value => {
        return `${value.name},${value.x},${value.y},${value.z},${value.mode},${value.dim},${value.time}`;
    });
    sendData.unshift(`setting,${setting.template_setting},${setting.dict},${setting.spectator}`);
    allPlayers.forEach((value, index) => {
        if (value.hasTag("host")) {
            value.removeTag("host");
            value.runCommand(`tell @s #POS${sendData.join(" ")}#POS`);
        }
    });
}, 20);